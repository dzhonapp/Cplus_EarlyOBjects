//
//  Inventory.h
//  C
//
//  Created by Bera on 4/6/17.
//  Copyright © 2017 WEST_LA. All rights reserved.
//

#ifndef Inventory_h
#define Inventory_h



class Inventory {
private:
    
    int itemNumber; // An int that holds the item’s number.
    
    int quantity; //An int that holds the quantity of the item on hand.
    
    double cost; //A double that holds the wholesale per-unit cost of the item
    
public:
    Inventory () {  // constructor without paramets-default constructor.
        itemNumber = 0;
        quantity = 0;
        cost = 0.0;
    }
    
    Inventory (int item, int quan, double price) { //Constructor with parameters
        
        setItemNumber(item);
        setQuantity(quan);
        setCost(price);
    }
    
    void setItemNumber(int item){ //Accepts an int argument and copies it into the itemNumber member variable.
        itemNumber=item;
    }
    void setQuantity(int quant) { //Accepts an int argument and copies it into the quantity member variable.
        quantity = quant;
    }
    void setCost(double price) { //Accepts a double argument and copies it into the cost member variable.
        cost = price;
    }
    
    int getItemNumber() { //Returns the value in itemNumber.
        return itemNumber;
    }
    int getQuantity () { //Returns the value in quantity.
        return quantity;
    }
    double getCost() { //Returns the value in cost.
        return cost;
    }
    
    double getTotalCost() {
        return getCost()*getQuantity(); //Computes and returns the totalCost.
    }
    
    
    
};


#endif /* Inventory_h */
