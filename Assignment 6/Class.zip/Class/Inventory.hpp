//
//  Inventory.hpp
//  C
//
//  Created by Bera on 4/6/17.
//  Copyright © 2017 WEST_LA. All rights reserved.
//

#ifndef Inventory_hpp
#define Inventory_hpp

#include <stdio.h>

#endif /* Inventory_hpp */
